#!/usr/bin/env python3
"""play_candycrush.py

Simplified, efficient implementation matching the project spec for 11x11 match-3 automation.
Usage example:
    python play_candycrush.py --games 100 --rows 11 --cols 11 --target 10000 --out results/summary.csv --seed 42

Outputs results CSV at --out.
"""
import argparse, copy, csv, os, random, time
from typing import List, Tuple, Set, Dict

Coord = Tuple[int,int]
Shape = Dict[str,object]

POINTS = {'line3':5, 'line4':10, 'line5':50, 'L33':20, 'T33':30}

def make_board(rows:int, cols:int, rng:random.Random)->List[List[int]]:
    return [[rng.randint(1,4) for _ in range(cols)] for _ in range(rows)]

def load_predefined(path:str)->List[List[List[int]]]:
    boards=[]
    cur=[]
    with open(path,'r',encoding='utf-8') as f:
        for line in f:
            s=line.strip()
            if s=='':
                if cur:
                    boards.append([list(map(int,row.split(','))) for row in cur])
                    cur=[]
            else:
                cur.append(s)
        if cur: boards.append([list(map(int,row.split(','))) for row in cur])
    return boards

def detect_all_shapes(board:List[List[int]])->List[Shape]:
    R=len(board); C=len(board[0])
    shapes=[]
    def add(kind,coords,pts):
        shapes.append({'kind':kind,'coords':coords,'points':pts})
    # horizontal lines
    for r in range(R):
        c=0
        while c<C:
            v=board[r][c]
            if v==0: c+=1; continue
            s=c
            while c+1<C and board[r][c+1]==v: c+=1
            L=c-s+1
            if L>=3:
                pts = POINTS['line5'] if L>=5 else (POINTS['line4'] if L==4 else POINTS['line3'])
                coords = {(r,cc) for cc in range(s,c+1)}
                add(f'line_h_{L}', coords, pts)
            c+=1
    # vertical lines
    for c in range(C):
        r=0
        while r<R:
            v=board[r][c]
            if v==0: r+=1; continue
            s=r
            while r+1<R and board[r+1][c]==v: r+=1
            L=r-s+1
            if L>=3:
                pts = POINTS['line5'] if L>=5 else (POINTS['line4'] if L==4 else POINTS['line3'])
                coords = {(rr,c) for rr in range(s,r+1)}
                add(f'line_v_{L}', coords, pts)
            r+=1
    # L shapes (3+3): corner cell is shared endpoint
    dirs=[(-1,0),(1,0),(0,-1),(0,1)]
    for r in range(R):
        for c in range(C):
            v=board[r][c]
            if v==0: continue
            for dr1,dc1 in dirs:
                for dr2,dc2 in dirs:
                    if dr1==dr2 and dc1==dc2: continue
                    if dr1+dr2==0 and dc1+dc2==0: continue
                    ok=True; coords=set()
                    for k in range(3):
                        rr=r+dr1*k; cc=c+dc1*k
                        if not (0<=rr<R and 0<=cc<C and board[rr][cc]==v): ok=False; break
                        coords.add((rr,cc))
                    if not ok: continue
                    for k in range(3):
                        rr=r+dr2*k; cc=c+dc2*k
                        if not (0<=rr<R and 0<=cc<C and board[rr][cc]==v): ok=False; break
                        coords.add((rr,cc))
                    if not ok: continue
                    if len(coords)==5:
                        add('L_3_3', coords, POINTS['L33'])
    # T shapes (3+3): center at intersection
    for r in range(R):
        for c in range(C):
            v=board[r][c]
            if v==0: continue
            try:
                if (0<=c-1<C and 0<=c+1<C and 0<=r-1<R and 0<=r+1<R and
                    board[r][c-1]==v and board[r][c+1]==v and board[r-1][c]==v and board[r+1][c]==v):
                    coords={(r,c-1),(r,c),(r,c+1),(r-1,c),(r+1,c)}; add('T_3_3_h',coords,POINTS['T33'])
            except:
                pass
    return shapes

def select_non_overlapping_shapes(shapes:List[Shape])->List[Shape]:
    shapes_sorted=sorted(shapes, key=lambda s:(-s['points'],-len(s['coords'])))
    used=set(); chosen=[]
    for s in shapes_sorted:
        if used.isdisjoint(s['coords']):
            chosen.append(s); used.update(s['coords'])
    return chosen

def apply_elimination_once(board:List[List[int]])->Tuple[int,int]:
    shapes=detect_all_shapes(board)
    if not shapes: return 0,0
    chosen=select_non_overlapping_shapes(shapes)
    pts=0
    for s in chosen:
        pts+=s['points']
        for (r,c) in s['coords']: board[r][c]=0
    return pts,len(chosen)

def apply_gravity_and_refill(board:List[List[int]], rng:random.Random)->None:
    R=len(board); C=len(board[0])
    for c in range(C):
        write=R-1
        for r in range(R-1,-1,-1):
            if board[r][c]!=0:
                board[write][c]=board[r][c]; write-=1
        for r in range(write,-1,-1):
            board[r][c]=rng.randint(1,4)

def run_full_cascade(board:List[List[int]], rng:random.Random)->Tuple[int,int]:
    total_pts=0; total_shapes=0
    while True:
        pts, cnt = apply_elimination_once(board)
        if cnt==0: break
        total_pts+=pts; total_shapes+=cnt
        apply_gravity_and_refill(board, rng)
    return total_pts, total_shapes

def all_adjacent_pairs(R:int,C:int):
    for r in range(R):
        for c in range(C):
            if c+1<C: yield (r,c),(r,c+1)
            if r+1<R: yield (r,c),(r+1,c)

def evaluate_swap(board:List[List[int]], a:Coord, b:Coord, rng:random.Random)->Tuple[int,int]:
    tmp=[row[:] for row in board]
    (ar,ac),(br,bc)=a,b
    tmp[ar][ac],tmp[br][bc]=tmp[br][bc],tmp[ar][ac]
    shapes=detect_all_shapes(tmp)
    if not shapes: return 0,0
    pts,casc=run_full_cascade(tmp,rng)
    return pts,casc

def find_best_valid_swap(board:List[List[int]], rng:random.Random):
    R=len(board); C=len(board[0]); best=None; best_pts=0; best_casc=0
    for a,b in all_adjacent_pairs(R,C):
        if board[a[0]][a[1]]==board[b[0]][b[1]]: continue
        pts,casc=evaluate_swap(board,a,b,rng)
        if pts>best_pts or (pts==best_pts and casc>best_casc):
            best_pts=pts; best_casc=casc; best=(a,b)
    return best,best_pts,best_casc

def play_single_game(initial_board:List[List[int]], target:int, rng:random.Random):
    board=[row[:] for row in initial_board]
    total_points=0; swaps_done=0; total_cascades=0; moves_to_10000=''
    pts,casc=run_full_cascade(board,rng)
    total_points+=pts; total_cascades+=casc
    while True:
        if total_points>=target: return {'points':total_points,'swaps':swaps_done,'total_cascades':total_cascades,'reached_target':True,'stopping_reason':'REACHED_TARGET','moves_to_10000':moves_to_10000}
        best,best_pts,best_casc=find_best_valid_swap(board,rng)
        if best is None: return {'points':total_points,'swaps':swaps_done,'total_cascades':total_cascades,'reached_target':False,'stopping_reason':'NO_MOVES','moves_to_10000':moves_to_10000}
        (a,b)=best; ar,ac=a; br,bc=b
        board[ar][ac],board[br][bc]=board[br][bc],board[ar][ac]
        pts,casc=run_full_cascade(board,rng)
        if pts==0: continue
        swaps_done+=1; total_points+=pts; total_cascades+=casc
        if total_points>=target and moves_to_10000=='': moves_to_10000=swaps_done

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--games',type=int,default=100)
    parser.add_argument('--rows',type=int,default=11); parser.add_argument('--cols',type=int,default=11)
    parser.add_argument('--target',type=int,default=10000); parser.add_argument('--input_predefined',type=str,default='')
    parser.add_argument('--out',type=str,default='results/summary.csv'); parser.add_argument('--seed',type=int,default=None)
    args=parser.parse_args()
    rng = random.Random(args.seed)
    predefined=[]
    if args.input_predefined: predefined=load_predefined(args.input_predefined)
    os.makedirs(os.path.dirname(args.out) or '.', exist_ok=True)
    rows_out=[]
    start=time.time()
    for gid in range(args.games):
        if gid < len(predefined): board=predefined[gid]
        else: board=make_board(args.rows,args.cols,rng)
        res=play_single_game(board,args.target,rng)
        rows_out.append((gid,res))
        if (gid+1)%10==0 or gid==args.games-1: print(f'Played {gid+1}/{args.games} games. Elapsed {time.time()-start:.1f}s')
    header=['game_id','points','swaps','total_cascades','reached_target','stopping_reason','moves_to_10000']
    with open(args.out,'w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(header)
        for gid,r in rows_out:
            w.writerow([gid,r['points'],r['swaps'],r['total_cascades'],str(r['reached_target']),r['stopping_reason'],r['moves_to_10000'] if r['moves_to_10000']!='' else ''])
    pts=[r['points'] for _,r in rows_out]; sw=[r['swaps'] for _,r in rows_out]
    print('Avg points:', sum(pts)/len(pts)); print('Avg swaps:', sum(sw)/len(sw))

if __name__=='__main__':
    main()