import importlib.util, sys, os
# Quick import of the script as module
spec = importlib.util.spec_from_file_location("pc", os.path.join(os.path.dirname(__file__), "..", "play_candycrush.py"))
mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
print("Module loaded OK")