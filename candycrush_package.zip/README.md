# CandyCrush Automation (11x11)

How to run:
1. Create a virtualenv and install requirements (optional):
   python -m venv venv; source venv/bin/activate; pip install -r requirements.txt
2. Run the script (example):
   python play_candycrush.py --games 100 --rows 11 --cols 11 --target 10000 --out results/summary.csv --seed 42

Outputs:
- results/summary.csv

Notes:
- Swap: single orthogonal swap between adjacent cells.
- Anti-duplication: greedy selection by points per elimination step.
